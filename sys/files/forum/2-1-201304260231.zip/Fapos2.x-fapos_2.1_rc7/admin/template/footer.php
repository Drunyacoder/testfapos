<?php
##################################################
##												##
## Author:       Andrey Brykin (Drunya)         ##
## Version:      0.7                            ##
## Project:      CMS                            ##
## package       CMS Fapos                      ##
## subpackege    Admin module                   ##
## copyright     ©Andrey Brykin 2010-2011       ##
##################################################


##################################################
##												##
## any partial or not partial extension         ##
## CMS Fapos,without the consent of the         ##
## author, is illegal                           ##
##################################################
## Любое распространение                        ##
## CMS Fapos или ее частей,                     ##
## без согласия автора, является не законным    ##
##################################################
?>
							</div>
							<div class="clear"></div>
							<div class="footer">(c) Fapos — 2013. All rights reserved.</div>
						</div>
						
					</td>
				</tr>
			</table>

		</div>	
	</div>
	<div id="overlay"></div>
</body>
</html>
