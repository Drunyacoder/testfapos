<?php

$smilesInfo = array(
	// Название сборки смайлов
    'name' => 'Стандартные смайлы Fapos',
	// Число смайлов для отображения в выпадающем меню (с начала списка)
    'show_count' => 30,
);

$smilesList = array(
	array(
		'from'	=> ':)',
		'to'	=> 'smile.gif'
	), array(
		'from'	=> '=)',
		'to'	=> 'tongue.gif'
	), array(
		'from'	=> '%)',
		'to'	=> 'nifiga.gif'
	), array(
		'from'	=> ':D',
		'to'	=> 'lol.gif'
	), array(
		'from'	=> 'gg)',
		'to'	=> 'gg.gif'
	), array(
		'from'	=> ':(',
		'to'	=> 'plak.gif'
	), array(
		'from'	=> '=0',
		'to'	=> 'glaza.gif'
	), array(
		'from'	=> ';)',
		'to'	=> 'biggrin2.gif'
	), array(
		'from'	=> ':0',
		'to'	=> 'biggrin.gif'
	), array(
		'from'	=> ':|',
		'to'	=> 'cool.gif'
	), array(
		'from'	=> '0_o',
		'to'	=> 'fing.gif'
	), array(
		'from' => ':baks:',
		'to' => 'baks.gif'
	), array(
		'from' => ':bis:',
		'to' => 'bis.gif'
	), array(
		'from' => ':girl:',
		'to' => 'girl.gif'
	), array(
		'from' => ':gordo:',
		'to' => 'gordo.gif'
	), array(
		'from' => ':gy:',
		'to' => 'gy.gif'
	), array(
		'from' => ':girlgy:',
		'to' => 'girlgy.gif'
	), array(
		'from' => ':haha:',
		'to' => 'haha.gif'
	), array(
		'from' => ':helpme:',
		'to' => 'helpme.gif'
	), array(
		'from' => ':hm:',
		'to' => 'hm.gif'
	), array(
		'from' => ':hnyk:',
		'to' => 'hnyk.gif'
	), array(
		'from' => ':idea:',
		'to' => 'idea.gif'
	), array(
		'from' => ':hrap:',
		'to' => 'hrap.gif'
	), array(
		'from' => ':ispug:',
		'to' => 'ispug.gif'
	), array(
		'from' => ':jahu:',
		'to' => 'jahu.gif'
	), array(
		'from' => ':girlhnyk:',
		'to' => 'girlhnyk.gif'
	), array(
		'from' => ':mat:',
		'to' => 'mat.gif'
	), array(
		'from' => ':mda:',
		'to' => 'mda.gif'
	), array(
		'from' => ':mdya:',
		'to' => 'mdya.gif'
	), array(
		'from' => ':or:',
		'to' => 'or.gif'
	), array(
		'from' => ':pardon:',
		'to' => 'pardon.gif'
	), array(
		'from' => ':plak:',
		'to' => 'plak.gif'
	), array(
		'from' => ':plaksa:',
		'to' => 'plaksa.gif'
	), array(
		'from' => ':plaksa2:',
		'to' => 'plaksa2.gif'
	), array(
		'from' => ':rzhu:',
		'to' => 'rzhu.gif'
	), array(
		'from' => ':sad:',
		'to' => 'sad.gif'
	), array(
		'from' => ':sarkastik:',
		'to' => 'sarkastik.gif'
	), array(
		'from' => ':sorrri:',
		'to' => 'sorrri.gif'
	), array(
		'from' => ':stranno:',
		'to' => 'stranno.gif'
	), array(
		'from' => ':tanz:',
		'to' => 'tanz.gif'
	), array(
		'from' => ':umora:',
		'to' => 'umora.gif'
	), array(
		'from' => ':ura:',
		'to' => 'ura.gif'
	), array(
		'from' => ':vopros:',
		'to' => 'vopros.gif'
	), array(
		'from' => ':wink:',
		'to' => 'wink.gif'
	), array(
		'from' => ':wutka:',
		'to' => 'wutka.gif'
	), array(
		'from' => ':ww:',
		'to' => 'ww.gif'
	), array(
		'from' => ':yeh:',
		'to' => 'yeh.gif'
	), array(
		'from' => ':zharko:',
		'to' => 'zharko.gif'
	), array(
		'from' => ':zlaya:',
		'to' => 'zlaya.gif'
	), array(
		'from' => ':zloy:',
		'to' => 'zloy.gif'
	), array(
		'from' => ':wall:',
		'to' => 'wall.gif'
	),
);

?>
