<?php

class Fps_Viewer_Node
{
	protected $body;
	
	
	
	public function __construct($body)
	{
		$this->body = $body;
	}
}