<?php
$FpsAllowModules = array(
	'addFields' => array(
		'news', 
		'stat', 
		'users', 
		'loads'
	),
	'addFieldsTitles' => array(
		'news' => 'Новости', 
		'stat' => 'Статьи', 
		'users' => 'Пользователи', 
		'loads' => 'Файлы'
	),
	'categories' => array(
		'news', 
		'loads', 
		'stat', 
		'foto'
	),
);
