<?php 
$acl_rules = array (
  'news' => 
  array (
    'view_list' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'view_materials' => 
    array (
      0 => 1,
      1 => 2,
      2 => 3,
      3 => 4,
      4 => 0,
    ),
    'add_materials' => 
    array (
      1 => 2,
      2 => 3,
      3 => 4,
    ),
    'edit_mine_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'edit_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_mine_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'up_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'on_home' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'view_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 0,
      5 => 1,
      6 => 2,
    ),
    'add_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 0,
      5 => 1,
      6 => 2,
    ),
    'edit_comments' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_comments' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'hide_material' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'record_comments_management' => 
    array (
      2 => 3,
      3 => 4,
    ),
  ),
  'stat' => 
  array (
    'view_list' => 
    array (
      0 => 1,
      1 => 2,
      2 => 3,
      3 => 4,
      4 => 0,
    ),
    'view_materials' => 
    array (
      0 => 1,
      1 => 2,
      2 => 3,
      3 => 4,
      4 => 0,
    ),
    'add_materials' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
    ),
    'edit_mine_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'edit_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_mine_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'up_materials' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'on_home' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'view_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 1,
      5 => 2,
      6 => 0,
    ),
    'add_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 1,
      5 => 2,
      6 => 0,
    ),
    'edit_comments' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_comments' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'hide_material' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'record_comments_management' => 
    array (
      2 => 3,
      3 => 4,
    ),
  ),
  'loads' => 
  array (
    'view_list' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 5,
      6 => 0,
    ),
    'view_materials' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'add_materials' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
    ),
    'edit_mine_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_mine_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'up_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'on_home' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'view_comments' => 
    array (
      3 => 4,
      4 => 3,
      5 => 1,
      6 => 2,
      7 => 0,
    ),
    'add_comments' => 
    array (
      3 => 4,
      4 => 3,
      5 => 1,
      6 => 2,
      7 => 0,
    ),
    'edit_comments' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_comments' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'hide_material' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'record_comments_management' => 
    array (
      2 => 3,
      3 => 4,
    ),
  ),
  'foto' => 
  array (
    'view_list' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'view_materials' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'add_materials' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
    ),
    'edit_mine_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_mine_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_materials' => 
    array (
      4 => 3,
      5 => 4,
    ),
    'up_materials' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'on_home' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'view_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 1,
      5 => 2,
      6 => 0,
    ),
    'add_comments' => 
    array (
      2 => 3,
      3 => 4,
      4 => 1,
      5 => 2,
      6 => 0,
    ),
    'edit_comments' => 
    array (
      2 => 3,
      3 => 4,
    ),
    'delete_comments' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'record_comments_management' => 
    array (
      2 => 3,
      3 => 4,
    ),
  ),
  'forum' => 
  array (
    'view_forums_list' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'view_forums' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'view_themes' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'add_themes' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
    ),
    'edit_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_mine_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_mine_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'close_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'important_themes' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'add_posts' => 
    array (
      0 => 1,
      3 => 4,
      4 => 3,
    ),
    'edit_posts' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_mine_posts' => 
    array (
      3 => 4,
      4 => 3,
      5 => 1,
    ),
    'delete_posts' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_mine_posts' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'add_forums' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_forums' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_forums' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'replace_forums' => 
    array (
      3 => 4,
      4 => 3,
    ),
  ),
  'users' => 
  array (
    'view_list' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'view_users' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
      5 => 0,
    ),
    'edit_users' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'edit_mine' => 
    array (
      0 => 1,
      1 => 2,
      3 => 4,
      4 => 3,
    ),
    'ban_users' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'set_rating' => 
    array (
      1 => 1,
      2 => 2,
      3 => 4,
      4 => 3,
    ),
    'delete_rating_comments' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'users_warnings' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'delete_warnings' => 
    array (
      3 => 4,
      4 => 3,
    ),
  ),
  'bbcodes' => 
  array (
    'bb_s' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      1 => 1,
    ),
    'bb_u' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      1 => 1,
    ),
    'bb_b' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      1 => 1,
    ),
    'bb_i' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      1 => 1,
    ),
    'bb_img' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      1 => 1,
    ),
    'bb_url' => 
    array (
      4 => 3,
      2 => 2,
      1 => 1,
      5 => 4,
    ),
    'html' => 
    array (
      5 => 4,
    ),
  ),
  'panel' => 
  array (
    'entry' => 
    array (
      0 => 3,
      1 => 4,
    ),
  ),
  'other' => 
  array (
    'can_see_hidden' => 
    array (
      3 => 4,
      4 => 3,
    ),
    'no_captcha' => 
    array (
      3 => 4,
      4 => 3,
      2 => 2,
      5 => 1,
    ),
  ),
  'chat' => 
  array (
    'view_materials' => 
    array (
      4 => 3,
      5 => 1,
      6 => 4,
      7 => 0,
    ),
    'add_materials' => 
    array (
      4 => 3,
      5 => 1,
      6 => 4,
      7 => 0,
    ),
    'delete_materials' => 
    array (
      4 => 3,
      5 => 4,
    ),
  ),
)
?>