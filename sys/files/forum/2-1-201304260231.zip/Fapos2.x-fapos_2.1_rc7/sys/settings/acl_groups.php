<?php 
$acl_groups = array (
  0 => 
  array (
    'title' => 'Гость',
    'color' => '',
  ),
  1 => 
  array (
    'title' => 'Юзер',
    'color' => 'grey',
  ),
  2 => 
  array (
    'title' => 'Пользователь',
    'color' => 'yellow',
  ),
  3 => 
  array (
    'title' => 'Модер',
    'color' => 'brown',
  ),
  4 => 
  array (
    'title' => 'Админ',
    'color' => 'EF1821',
  ),
);
