<?php 
$forum_rules = array ();
?>