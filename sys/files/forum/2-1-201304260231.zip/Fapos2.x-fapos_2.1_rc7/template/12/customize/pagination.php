<?php
/*
function custom_pagination( $page, $cntPages, $url ) {

}
*/
?>